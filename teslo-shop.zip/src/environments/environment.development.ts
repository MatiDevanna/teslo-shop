export const environment = {
  baseUrl: 'http://localhost:3000/api',
};
